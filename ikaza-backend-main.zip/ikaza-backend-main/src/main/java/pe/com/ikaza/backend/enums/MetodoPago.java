package pe.com.ikaza.backend.enums;

public enum MetodoPago {
    MERCADO_PAGO,
    TRANSFERENCIA_BANCARIA,
    EFECTIVO_CONTRAENTREGA
}
